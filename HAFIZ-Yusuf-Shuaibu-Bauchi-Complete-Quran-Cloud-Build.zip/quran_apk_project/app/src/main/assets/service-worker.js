/* =========================================================
   QUR'AN AUDIO APP
   SERVICE WORKER
   Version 1.0.2
   Published by: Rabilu Muhammad
   ========================================================= */

const CACHE_NAME = "quran-audio-v1.0.2";

const APP_FILES = [
   "./",
   "./index.html",
   "./style.css",
   "./script.js",
   "./manifest.json"
];

/* =========================================================
   INSTALL
   ========================================================= */

self.addEventListener("install", (event) => {
   
   event.waitUntil(
      
      caches.open(CACHE_NAME)
      
      .then((cache) => {
         
         return cache.addAll(APP_FILES);
         
      })
      
      .catch((error) => {
         
         console.error(
            "Cache installation failed:",
            error
         );
         
      })
      
   );
   
   self.skipWaiting();
   
});


/* =========================================================
   ACTIVATE
   ========================================================= */

self.addEventListener("activate", (event) => {
   
   event.waitUntil(
      
      caches.keys()
      
      .then((cacheNames) => {
         
         return Promise.all(
            
            cacheNames
            
            .filter((name) => {
               
               return name !== CACHE_NAME;
               
            })
            
            .map((name) => {
               
               return caches.delete(name);
               
            })
            
         );
         
      })
      
      .then(() => {
         
         return self.clients.claim();
         
      })
      
   );
   
});


/* =========================================================
   FETCH
   ========================================================= */

self.addEventListener("fetch", (event) => {
   
   if (event.request.method !== "GET") {
      
      return;
      
   }
   
   event.respondWith(
      
      fetch(event.request)
      
      .then((networkResponse) => {
         
         if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === "basic"
         ) {
            
            const responseToCache =
               networkResponse.clone();
            
            caches.open(CACHE_NAME)
               
               .then((cache) => {
                  
                  cache.put(
                     event.request,
                     responseToCache
                  );
                  
               });
            
         }
         
         return networkResponse;
         
      })
      
      .catch(() => {
         
         return caches.match(event.request);
         
      })
      
   );
   
});