HAFIZ Yusuf Shuaibu Bauchi Complete Qur’an

CLOUD APK BUILD
================
This project includes a GitHub Actions workflow at:
.github/workflows/build-apk.yml

How to build without AndroidIDE:
1. Create a GitHub repository.
2. Upload the CONTENTS of this quran_apk_project folder to the repository root.
3. Open the repository -> Actions.
4. Select “Build Qur’an APK”.
5. Tap “Run workflow”.
6. When the job finishes, open the run and download the artifact named:
   HAFIZ-Yusuf-Shuaibu-Bauchi-Complete-Quran-APK

The generated file is a debug APK for testing on Android.

IMPORTANT:
- Do not delete or rename the app/src/main/assets folder.
- The current project contains audio/001.mp3 only; the other 113 audio files are not included in this ZIP.
- Existing web-app features are kept as supplied.
