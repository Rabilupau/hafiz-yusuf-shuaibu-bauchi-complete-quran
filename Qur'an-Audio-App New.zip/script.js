/* =========================================================
   HAFIZ YUSUF SHUAIBU BAUCHI COMPLETE QUR’AN
   COMPLETE SCRIPT.JS
   Version 1.1.1
   Published by: Rabilu Muhammad
   Reciter: Yusuf Shuaibu Bauchi
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    /* =====================================================
       SURAH DATA - ALL 114 SURAHS
       ===================================================== */

    const surahs = [
        { number: 1, english: "Al-Fatihah", arabic: "الفاتحة" },
        { number: 2, english: "Al-Baqarah", arabic: "البقرة" },
        { number: 3, english: "Aal-E-Imran", arabic: "آل عمران" },
        { number: 4, english: "An-Nisa", arabic: "النساء" },
        { number: 5, english: "Al-Maidah", arabic: "المائدة" },
        { number: 6, english: "Al-Anam", arabic: "الأنعام" },
        { number: 7, english: "Al-Araf", arabic: "الأعراف" },
        { number: 8, english: "Al-Anfal", arabic: "الأنفال" },
        { number: 9, english: "At-Tawbah", arabic: "التوبة" },
        { number: 10, english: "Yunus", arabic: "يونس" },
        { number: 11, english: "Hud", arabic: "هود" },
        { number: 12, english: "Yusuf", arabic: "يوسف" },
        { number: 13, english: "Ar-Rad", arabic: "الرعد" },
        { number: 14, english: "Ibrahim", arabic: "إبراهيم" },
        { number: 15, english: "Al-Hijr", arabic: "الحجر" },
        { number: 16, english: "An-Nahl", arabic: "النحل" },
        { number: 17, english: "Al-Isra", arabic: "الإسراء" },
        { number: 18, english: "Al-Kahf", arabic: "الكهف" },
        { number: 19, english: "Maryam", arabic: "مريم" },
        { number: 20, english: "Ta-Ha", arabic: "طه" },
        { number: 21, english: "Al-Anbiya", arabic: "الأنبياء" },
        { number: 22, english: "Al-Hajj", arabic: "الحج" },
        { number: 23, english: "Al-Muminun", arabic: "المؤمنون" },
        { number: 24, english: "An-Nur", arabic: "النور" },
        { number: 25, english: "Al-Furqan", arabic: "الفرقان" },
        { number: 26, english: "Ash-Shuara", arabic: "الشعراء" },
        { number: 27, english: "An-Naml", arabic: "النمل" },
        { number: 28, english: "Al-Qasas", arabic: "القصص" },
        { number: 29, english: "Al-Ankabut", arabic: "العنكبوت" },
        { number: 30, english: "Ar-Rum", arabic: "الروم" },
        { number: 31, english: "Luqman", arabic: "لقمان" },
        { number: 32, english: "As-Sajdah", arabic: "السجدة" },
        { number: 33, english: "Al-Ahzab", arabic: "الأحزاب" },
        { number: 34, english: "Saba", arabic: "سبأ" },
        { number: 35, english: "Fatir", arabic: "فاطر" },
        { number: 36, english: "Ya-Sin", arabic: "يس" },
        { number: 37, english: "As-Saffat", arabic: "الصافات" },
        { number: 38, english: "Sad", arabic: "ص" },
        { number: 39, english: "Az-Zumar", arabic: "الزمر" },
        { number: 40, english: "Ghafir", arabic: "غافر" },
        { number: 41, english: "Fussilat", arabic: "فصلت" },
        { number: 42, english: "Ash-Shura", arabic: "الشورى" },
        { number: 43, english: "Az-Zukhruf", arabic: "الزخرف" },
        { number: 44, english: "Ad-Dukhan", arabic: "الدخان" },
        { number: 45, english: "Al-Jathiyah", arabic: "الجاثية" },
        { number: 46, english: "Al-Ahqaf", arabic: "الأحقاف" },
        { number: 47, english: "Muhammad", arabic: "محمد" },
        { number: 48, english: "Al-Fath", arabic: "الفتح" },
        { number: 49, english: "Al-Hujurat", arabic: "الحجرات" },
        { number: 50, english: "Qaf", arabic: "ق" },
        { number: 51, english: "Adh-Dhariyat", arabic: "الذاريات" },
        { number: 52, english: "At-Tur", arabic: "الطور" },
        { number: 53, english: "An-Najm", arabic: "النجم" },
        { number: 54, english: "Al-Qamar", arabic: "القمر" },
        { number: 55, english: "Ar-Rahman", arabic: "الرحمن" },
        { number: 56, english: "Al-Waqiah", arabic: "الواقعة" },
        { number: 57, english: "Al-Hadid", arabic: "الحديد" },
        { number: 58, english: "Al-Mujadilah", arabic: "المجادلة" },
        { number: 59, english: "Al-Hashr", arabic: "الحشر" },
        { number: 60, english: "Al-Mumtahanah", arabic: "الممتحنة" },
        { number: 61, english: "As-Saff", arabic: "الصف" },
        { number: 62, english: "Al-Jumuah", arabic: "الجمعة" },
        { number: 63, english: "Al-Munafiqun", arabic: "المنافقون" },
        { number: 64, english: "At-Taghabun", arabic: "التغابن" },
        { number: 65, english: "At-Talaq", arabic: "الطلاق" },
        { number: 66, english: "At-Tahrim", arabic: "التحريم" },
        { number: 67, english: "Al-Mulk", arabic: "الملك" },
        { number: 68, english: "Al-Qalam", arabic: "القلم" },
        { number: 69, english: "Al-Haqqah", arabic: "الحاقة" },
        { number: 70, english: "Al-Maarij", arabic: "المعارج" },
        { number: 71, english: "Nuh", arabic: "نوح" },
        { number: 72, english: "Al-Jinn", arabic: "الجن" },
        { number: 73, english: "Al-Muzzammil", arabic: "المزمل" },
        { number: 74, english: "Al-Muddaththir", arabic: "المدثر" },
        { number: 75, english: "Al-Qiyamah", arabic: "القيامة" },
        { number: 76, english: "Al-Insan", arabic: "الإنسان" },
        { number: 77, english: "Al-Mursalat", arabic: "المرسلات" },
        { number: 78, english: "An-Naba", arabic: "النبأ" },
        { number: 79, english: "An-Naziat", arabic: "النازعات" },
        { number: 80, english: "Abasa", arabic: "عبس" },
        { number: 81, english: "At-Takwir", arabic: "التكوير" },
        { number: 82, english: "Al-Infitar", arabic: "الانفطار" },
        { number: 83, english: "Al-Mutaffifin", arabic: "المطففين" },
        { number: 84, english: "Al-Inshiqaq", arabic: "الانشقاق" },
        { number: 85, english: "Al-Buruj", arabic: "البروج" },
        { number: 86, english: "At-Tariq", arabic: "الطارق" },
        { number: 87, english: "Al-Ala", arabic: "الأعلى" },
        { number: 88, english: "Al-Ghashiyah", arabic: "الغاشية" },
        { number: 89, english: "Al-Fajr", arabic: "الفجر" },
        { number: 90, english: "Al-Balad", arabic: "البلد" },
        { number: 91, english: "Ash-Shams", arabic: "الشمس" },
        { number: 92, english: "Al-Layl", arabic: "الليل" },
        { number: 93, english: "Ad-Duha", arabic: "الضحى" },
        { number: 94, english: "Ash-Sharh", arabic: "الشرح" },
        { number: 95, english: "At-Tin", arabic: "التين" },
        { number: 96, english: "Al-Alaq", arabic: "العلق" },
        { number: 97, english: "Al-Qadr", arabic: "القدر" },
        { number: 98, english: "Al-Bayyinah", arabic: "البينة" },
        { number: 99, english: "Az-Zalzalah", arabic: "الزلزلة" },
        { number: 100, english: "Al-Adiyat", arabic: "العاديات" },
        { number: 101, english: "Al-Qariah", arabic: "القارعة" },
        { number: 102, english: "At-Takathur", arabic: "التكاثر" },
        { number: 103, english: "Al-Asr", arabic: "العصر" },
        { number: 104, english: "Al-Humazah", arabic: "الهمزة" },
        { number: 105, english: "Al-Fil", arabic: "الفيل" },
        { number: 106, english: "Quraysh", arabic: "قريش" },
        { number: 107, english: "Al-Maun", arabic: "الماعون" },
        { number: 108, english: "Al-Kawthar", arabic: "الكوثر" },
        { number: 109, english: "Al-Kafirun", arabic: "الكافرون" },
        { number: 110, english: "An-Nasr", arabic: "النصر" },
        { number: 111, english: "Al-Masad", arabic: "المسد" },
        { number: 112, english: "Al-Ikhlas", arabic: "الإخلاص" },
        { number: 113, english: "Al-Falaq", arabic: "الفلق" },
        { number: 114, english: "An-Nas", arabic: "الناس" }
    ];


    /* =====================================================
       ELEMENTS
       ===================================================== */

    const menuButton =
        document.getElementById("menuButton");

    const favoritesButton =
        document.getElementById("favoritesButton");

    const menuOverlay =
        document.getElementById("menuOverlay");

    const sideMenu =
        document.getElementById("sideMenu");

    const darkModeButton =
        document.getElementById("darkModeButton");

    const shareAppButton =
        document.getElementById("shareAppButton");

    const surahList =
        document.getElementById("surahList");

    const surahsPageList =
        document.getElementById("surahsPageList");

    const favoritesList =
        document.getElementById("favoritesList");

    const playlistList =
        document.getElementById("playlistList");

    const favoritesEmpty =
        document.getElementById("favoritesEmpty");

    const playlistEmpty =
        document.getElementById("playlistEmpty");

    const searchInput =
        document.getElementById("searchInput");

    const clearSearch =
        document.getElementById("clearSearch");

    const surahsSearchInput =
        document.getElementById("surahsSearchInput");

    const clearSurahsSearch =
        document.getElementById("clearSurahsSearch");

    const homeNoResults =
        document.getElementById("homeNoResults");

    const surahsPageNoResults =
        document.getElementById("surahsPageNoResults");

    const homeSurahCount =
        document.getElementById("homeSurahCount");

    const surahsPageCount =
        document.getElementById("surahsPageCount");

    const audioElement =
        document.getElementById("audioElement");

    const currentSurahName =
        document.getElementById("currentSurahName");

    const currentSurahArabic =
        document.getElementById("currentSurahArabic");

    const currentReciter =
        document.getElementById("currentReciter");

    const currentTime =
        document.getElementById("currentTime");

    const duration =
        document.getElementById("duration");

    const progressBar =
        document.getElementById("progressBar");

    const playPauseButton =
        document.getElementById("playPauseButton");

    const previousButton =
        document.getElementById("previousButton");

    const nextButton =
        document.getElementById("nextButton");

    const rewindButton =
        document.getElementById("rewindButton");

    const forwardButton =
        document.getElementById("forwardButton");

    const playerMoreButton =
        document.getElementById("playerMoreButton");

    const secondaryControls =
        document.getElementById("secondaryControls");

    const repeatButton =
        document.getElementById("repeatButton");

    const playerFavoriteButton =
        document.getElementById("playerFavoriteButton");

    const continueSection =
        document.getElementById("continueSection");

    const continueCard =
        document.getElementById("continueCard");

    const toast =
        document.getElementById("toast");

    const toastMessage =
        document.getElementById("toastMessage");

    const playPlaylistButton =
        document.getElementById("playPlaylistButton");


    /* =====================================================
       STATE
       ===================================================== */

    let currentSurah =
        Number(localStorage.getItem("lastSurah")) || 1;

    let favorites =
        JSON.parse(
            localStorage.getItem("quranFavorites") || "[]"
        );

    let playlist =
        JSON.parse(
            localStorage.getItem("quranPlaylist") || "[]"
        );

    let repeatMode =
        localStorage.getItem("quranRepeat") === "true";

    let currentPage =
        localStorage.getItem("quranCurrentPage") || "home";

    let playlistIndex = -1;


    /* =====================================================
       DURATION CACHE
       ===================================================== */

    const durationCache =
        JSON.parse(
            localStorage.getItem("quranDurations") || "{}"
        );


    function saveDurationCache() {

        try {

            localStorage.setItem(
                "quranDurations",
                JSON.stringify(durationCache)
            );

        } catch (error) {

            console.warn(
                "Could not save duration cache:",
                error
            );

        }

    }


    function setSurahDurationOnCards(number) {

        const value =
            durationCache[String(number)];

        if (!value) return;

        document
            .querySelectorAll(
                `[data-duration-for="${number}"]`
            )
            .forEach((element) => {

                element.textContent = value;

            });

    }


    function cacheCurrentDuration() {

        if (
            !audioElement ||
            !Number.isFinite(audioElement.duration)
        ) {
            return;
        }

        const formatted =
            formatTime(audioElement.duration);

        durationCache[String(currentSurah)] =
            formatted;

        saveDurationCache();

        setSurahDurationOnCards(currentSurah);

    }


    /* =====================================================
       AUDIO PATH
       ===================================================== */

    function getAudioUrl(number) {

        const fileNumber =
            String(number).padStart(3, "0");

        return `./audio/${fileNumber}.mp3`;

    }


    /* =====================================================
       SERVICE WORKER
       ===================================================== */

    if ("serviceWorker" in navigator) {

        window.addEventListener(
            "load",
            () => {

                navigator.serviceWorker
                    .register("./service-worker.js")
                    .then(() => {

                        console.log(
                            "Qur'an service worker registered."
                        );

                    })
                    .catch((error) => {

                        console.error(
                            "Service worker registration failed:",
                            error
                        );

                    });

            }
        );

    }


    /* =====================================================
       STORAGE
       ===================================================== */

    function saveFavorites() {

        localStorage.setItem(
            "quranFavorites",
            JSON.stringify(favorites)
        );

    }


    function savePlaylist() {

        localStorage.setItem(
            "quranPlaylist",
            JSON.stringify(playlist)
        );

    }


    /* =====================================================
       TOAST
       ===================================================== */

    function showToast(message) {

        if (!toast || !toastMessage) return;

        toastMessage.textContent = message;

        toast.classList.add("show");

        setTimeout(() => {

            toast.classList.remove("show");

        }, 2200);

    }


    /* =====================================================
       SURAH CARD
       Arabic + Latin + Duration + PLAY ONLY
       ===================================================== */

    function createSurahCard(surah) {

        const card =
            document.createElement("div");

        card.className = "surah-card";

        card.dataset.number =
            String(surah.number);

        card.innerHTML = `

            <div class="surah-number">
                ${surah.number}
            </div>

            <div class="surah-info">

                <span class="surah-arabic">
                    ${surah.arabic}
                </span>

                <span class="surah-name surah-latin">
                    ${surah.english}
                </span>

                <span
                    class="surah-duration"
                    data-duration-for="${surah.number}">
                    ${durationCache[String(surah.number)] || "—:—"}
                </span>

            </div>

            <div class="surah-actions">

                <button
                    class="surah-action play-action"
                    type="button"
                    title="Play ${surah.english}"
                    aria-label="Play ${surah.english}">
                    ▶️
                </button>

            </div>
        `;


        card.addEventListener(
            "click",
            (event) => {

                if (
                    event.target.closest(".play-action")
                ) {
                    return;
                }

                loadSurah(
                    surah.number,
                    true
                );

            }
        );


        const playAction =
            card.querySelector(".play-action");


        if (playAction) {

            playAction.addEventListener(
                "click",
                (event) => {

                    event.preventDefault();
                    event.stopPropagation();

                    loadSurah(
                        surah.number,
                        true
                    );

                }
            );

        }


        return card;

    }


    /* =====================================================
       RENDER HOME
       ===================================================== */

    function renderHome(list = surahs) {

        if (!surahList) return;

        surahList.innerHTML = "";

        list.forEach((surah) => {

            surahList.appendChild(
                createSurahCard(surah)
            );

        });


        if (homeSurahCount) {

            homeSurahCount.textContent =
                list.length;

        }


        if (homeNoResults) {

            homeNoResults.style.display =
                list.length === 0
                    ? "block"
                    : "none";

        }

    }


    /* =====================================================
       RENDER SURAHS PAGE
       ===================================================== */

    function renderSurahsPage(list = surahs) {

        if (!surahsPageList) return;

        surahsPageList.innerHTML = "";

        list.forEach((surah) => {

            surahsPageList.appendChild(
                createSurahCard(surah)
            );

        });


        if (surahsPageCount) {

            surahsPageCount.textContent =
                list.length;

        }


        if (surahsPageNoResults) {

            surahsPageNoResults.style.display =
                list.length === 0
                    ? "block"
                    : "none";

        }

    }


    /* =====================================================
       FAVORITES
       ===================================================== */

    function toggleFavorite(number) {

        const index =
            favorites.indexOf(number);


        if (index === -1) {

            favorites.push(number);

            showToast("Added to Favorites");

        } else {

            favorites.splice(index, 1);

            showToast("Removed from Favorites");

        }


        saveFavorites();

        renderHome();
        renderSurahsPage();
        renderFavorites();

        updatePlayerFavorite();

    }


    function renderFavorites() {

        if (!favoritesList) return;

        favoritesList.innerHTML = "";

        const favoriteSurahs =
            surahs.filter(
                (surah) =>
                    favorites.includes(
                        surah.number
                    )
            );


        favoriteSurahs.forEach((surah) => {

            favoritesList.appendChild(
                createSurahCard(surah)
            );

        });


        if (favoritesEmpty) {

            favoritesEmpty.style.display =
                favoriteSurahs.length === 0
                    ? "block"
                    : "none";

        }

    }


    /* =====================================================
       PLAYLIST
       ===================================================== */

    function togglePlaylist(number) {

        const index =
            playlist.indexOf(number);


        if (index === -1) {

            playlist.push(number);

            showToast("Added to Playlist");

        } else {

            playlist.splice(index, 1);

            showToast("Removed from Playlist");

        }


        savePlaylist();

        renderHome();
        renderSurahsPage();
        renderPlaylist();

    }


    function renderPlaylist() {

        if (!playlistList) return;

        playlistList.innerHTML = "";

        const playlistSurahs =
            playlist
                .map((number) =>
                    surahs.find(
                        (surah) =>
                            surah.number === number
                    )
                )
                .filter(Boolean);


        playlistSurahs.forEach((surah) => {

            playlistList.appendChild(
                createSurahCard(surah)
            );

        });


        if (playlistEmpty) {

            playlistEmpty.style.display =
                playlistSurahs.length === 0
                    ? "block"
                    : "none";

        }

    }


    /* =====================================================
       PLAYER
       ===================================================== */

    function loadSurah(number, autoPlay = false) {

        const surah =
            surahs.find(
                (item) =>
                    item.number === Number(number)
            );


        if (!surah) return;


        currentSurah =
            surah.number;


        if (currentSurahName) {

            currentSurahName.textContent =
                surah.english;

        }


        if (currentSurahArabic) {

            currentSurahArabic.textContent =
                surah.arabic;

        }


        if (currentReciter) {

            currentReciter.textContent =
                "Yusuf Shuaibu Bauchi";

        }


        const audioUrl =
            getAudioUrl(surah.number);


        if (!audioElement) return;


        audioElement.pause();

        audioElement.src = audioUrl;

        audioElement.load();


        localStorage.setItem(
            "lastSurah",
            String(surah.number)
        );

        localStorage.setItem(
            "lastSurahName",
            surah.english
        );


        if (progressBar) {

            progressBar.value = 0;

        }


        if (currentTime) {

            currentTime.textContent =
                "0:00";

        }


        if (duration) {

            duration.textContent =
                durationCache[
                    String(surah.number)
                ] || "0:00";

        }


        updatePlayerFavorite();

        updateContinueCard();


        if (autoPlay) {

            const playPromise =
                audioElement.play();


            if (
                playPromise &&
                typeof playPromise.catch === "function"
            ) {

                playPromise.catch(() => {

                    showToast(
                        "Tap Play to start the audio"
                    );

                });

            }

        }

    }


    function togglePlay() {

        if (!audioElement) return;


        if (!audioElement.src) {

            loadSurah(
                currentSurah,
                false
            );

        }


        if (audioElement.paused) {

            audioElement
                .play()
                .catch(() => {

                    showToast(
                        "Unable to play this audio"
                    );

                });

        } else {

            audioElement.pause();

        }

    }


    function updatePlayButton() {

        if (!playPauseButton) return;

        playPauseButton.textContent =
            audioElement.paused
                ? "▶️"
                : "⏸️";

    }


    /* =====================================================
       NEXT / PREVIOUS
       ===================================================== */

    function playNextSurah() {

        let nextNumber =
            currentSurah + 1;


        if (playlist.length > 0) {

            const currentIndex =
                playlist.indexOf(currentSurah);


            if (currentIndex !== -1) {

                const nextIndex =
                    currentIndex + 1;


                if (
                    nextIndex <
                    playlist.length
                ) {

                    playlistIndex =
                        nextIndex;

                    loadSurah(
                        playlist[nextIndex],
                        true
                    );

                    return;

                }

            }

        }


        if (nextNumber > 114) {

            nextNumber = 1;

        }


        loadSurah(
            nextNumber,
            true
        );

    }


    function playPreviousSurah() {

        let previousNumber =
            currentSurah - 1;


        if (previousNumber < 1) {

            previousNumber = 114;

        }


        loadSurah(
            previousNumber,
            true
        );

    }


    /* =====================================================
       REWIND / FORWARD
       ===================================================== */

    function rewind10() {

        if (
            !audioElement ||
            !audioElement.duration
        ) {
            return;
        }


        audioElement.currentTime =
            Math.max(
                0,
                audioElement.currentTime - 10
            );

    }


    function forward10() {

        if (
            !audioElement ||
            !audioElement.duration
        ) {
            return;
        }


        audioElement.currentTime =
            Math.min(
                audioElement.duration,
                audioElement.currentTime + 10
            );

    }


    /* =====================================================
       TIME FORMAT
       ===================================================== */

    function formatTime(seconds) {

        if (
            !Number.isFinite(seconds)
        ) {
            return "0:00";
        }


        const minutes =
            Math.floor(seconds / 60);

        const secs =
            Math.floor(seconds % 60);


        return (
            minutes +
            ":" +
            String(secs).padStart(2, "0")
        );

    }


    /* =====================================================
       AUDIO EVENTS
       ===================================================== */

    if (audioElement) {

        audioElement.addEventListener(
            "loadedmetadata",
            () => {

                if (
                    Number.isFinite(
                        audioElement.duration
                    )
                ) {

                    const formatted =
                        formatTime(
                            audioElement.duration
                        );


                    if (duration) {

                        duration.textContent =
                            formatted;

                    }


                    durationCache[
                        String(currentSurah)
                    ] = formatted;


                    saveDurationCache();

                    setSurahDurationOnCards(
                        currentSurah
                    );

                }

            }
        );


        audioElement.addEventListener(
            "timeupdate",
            () => {

                const current =
                    audioElement.currentTime;

                const total =
                    audioElement.duration;


                if (currentTime) {

                    currentTime.textContent =
                        formatTime(current);

                }


                if (
                    progressBar &&
                    Number.isFinite(total) &&
                    total > 0
                ) {

                    progressBar.value =
                        (current / total) * 100;

                }

            }
        );


        audioElement.addEventListener(
            "play",
            () => {

                updatePlayButton();

                updateContinueCard();

            }
        );


        audioElement.addEventListener(
            "pause",
            () => {

                updatePlayButton();

            }
        );


        audioElement.addEventListener(
            "ended",
            () => {

                if (repeatMode) {

                    audioElement.currentTime = 0;

                    audioElement
                        .play()
                        .catch(() => {});

                    return;

                }


                playNextSurah();

            }
        );


        audioElement.addEventListener(
            "error",
            () => {

                console.error(
                    "Audio error:",
                    audioElement.error
                );

                showToast(
                    "Audio file could not be loaded"
                );

            }
        );

    }


    /* =====================================================
       PROGRESS BAR
       ===================================================== */

    if (progressBar) {

        progressBar.addEventListener(
            "input",
            () => {

                if (
                    !audioElement ||
                    !audioElement.duration
                ) {
                    return;
                }


                audioElement.currentTime =
                    (Number(progressBar.value) / 100) *
                    audioElement.duration;

            }
        );

    }


    /* =====================================================
       REPEAT
       ===================================================== */

    function updateRepeatButton() {

        if (!repeatButton) return;

        repeatButton.classList.toggle(
            "active",
            repeatMode
        );

    }


    if (repeatButton) {

        repeatButton.addEventListener(
            "click",
            () => {

                repeatMode =
                    !repeatMode;


                localStorage.setItem(
                    "quranRepeat",
                    String(repeatMode)
                );


                updateRepeatButton();


                showToast(
                    repeatMode
                        ? "Repeat On"
                        : "Repeat Off"
                );

            }
        );

    }


    /* =====================================================
       PLAYER FAVORITE
       ===================================================== */

    function updatePlayerFavorite() {

        if (!playerFavoriteButton) {
            return;
        }


        const isFavorite =
            favorites.includes(currentSurah);


        playerFavoriteButton.innerHTML =
            `
            ${isFavorite ? "★" : "☆"}
            <span>Favorite</span>
            `;

    }


    if (playerFavoriteButton) {

        playerFavoriteButton.addEventListener(
            "click",
            () => {

                toggleFavorite(
                    currentSurah
                );

            }
        );

    }


    /* =====================================================
       PLAYER MORE
       ===================================================== */

    if (playerMoreButton) {

        playerMoreButton.addEventListener(
            "click",
            () => {

                if (!secondaryControls) {
                    return;
                }


                const hidden =
                    secondaryControls.style.display === "none" ||
                    secondaryControls.style.display === "";


                secondaryControls.style.display =
                    hidden ? "flex" : "none";

            }
        );

    }


    /* =====================================================
       MENU
       ===================================================== */

    function openMenu() {

        if (sideMenu) {

            sideMenu.classList.add("open");
            sideMenu.classList.add("active");

        }


        if (menuOverlay) {

            menuOverlay.classList.add("active");

            menuOverlay.style.display = "block";
            menuOverlay.style.pointerEvents = "auto";

        }


        document.body.classList.add(
            "menu-open"
        );

    }


    function closeMenu() {

        if (sideMenu) {

            sideMenu.classList.remove("open");
            sideMenu.classList.remove("active");

        }


        if (menuOverlay) {

            menuOverlay.classList.remove("active");

            menuOverlay.style.display = "";
            menuOverlay.style.pointerEvents = "";

        }


        document.body.classList.remove(
            "menu-open"
        );

    }


    /* =====================================================
       THREE-LINE MENU BUTTON
       ===================================================== */

    if (menuButton) {

        menuButton.onclick =
            function(event) {

                event.preventDefault();
                event.stopPropagation();


                if (
                    sideMenu &&
                    sideMenu.classList.contains("open")
                ) {

                    closeMenu();

                } else {

                    openMenu();

                }

            };

    } else {

        console.warn(
            "menuButton was not found in index.html"
        );

    }


    /* =====================================================
       MENU OVERLAY
       ===================================================== */

    if (menuOverlay) {

        menuOverlay.onclick =
            function(event) {

                event.preventDefault();
                event.stopPropagation();

                closeMenu();

            };

    }


    /* =====================================================
       ESC KEY CLOSE MENU
       ===================================================== */

    document.addEventListener(
        "keydown",
        (event) => {

            if (event.key === "Escape") {

                closeMenu();

            }

        }
    );


    /* =====================================================
       PAGE NAVIGATION
       ===================================================== */

    function showPage(pageName) {

        const pages =
            document.querySelectorAll(".page");


        pages.forEach((page) => {

            page.classList.remove(
                "active-page",
                "active"
            );

        });


        const targetPage =
            document.getElementById(
                pageName + "Page"
            );


        if (targetPage) {

            targetPage.classList.add(
                "active"
            );

        }


        document
            .querySelectorAll(
                ".menu-link[data-page]"
            )
            .forEach((button) => {

                button.classList.toggle(
                    "active",
                    button.dataset.page === pageName
                );

            });


        currentPage = pageName;


        localStorage.setItem(
            "quranCurrentPage",
            pageName
        );


        closeMenu();


        window.scrollTo({
            top: 0,
            left: 0,
            behavior: "auto"
        });

    }


    /* =====================================================
       PAGE BUTTONS
       ===================================================== */

    document
        .querySelectorAll("[data-page]")
        .forEach((button) => {

            button.addEventListener(
                "click",
                (event) => {

                    event.preventDefault();

                    const pageName =
                        button.dataset.page;

                    if (pageName) {

                        showPage(pageName);

                    }

                }
            );

        });


    /* =====================================================
       FAVORITES HEADER BUTTON
       ===================================================== */

    if (favoritesButton) {

        favoritesButton.addEventListener(
            "click",
            () => {

                renderFavorites();

                showPage("favorites");

            }
        );

    }


    /* =====================================================
       SEARCH HOME
       ===================================================== */

    function searchSurahs(value) {

        const query =
            value.trim().toLowerCase();


        const filtered =
            surahs.filter((surah) => {

                return (
                    surah.english
                        .toLowerCase()
                        .includes(query) ||

                    surah.arabic
                        .includes(query) ||

                    String(surah.number)
                        .includes(query)
                );

            });


        renderHome(filtered);

    }


    if (searchInput) {

        searchInput.addEventListener(
            "input",
            () => {

                searchSurahs(
                    searchInput.value
                );

            }
        );

    }


    if (clearSearch) {

        clearSearch.addEventListener(
            "click",
            () => {

                if (searchInput) {

                    searchInput.value = "";

                    renderHome();

                    searchInput.focus();

                }

            }
        );

    }


    /* =====================================================
       SEARCH SURAHS PAGE
       ===================================================== */

    function searchSurahsPage(value) {

        const query =
            value.trim().toLowerCase();


        const filtered =
            surahs.filter((surah) => {

                return (
                    surah.english
                        .toLowerCase()
                        .includes(query) ||

                    surah.arabic
                        .includes(query) ||

                    String(surah.number)
                        .includes(query)
                );

            });


        renderSurahsPage(filtered);

    }


    if (surahsSearchInput) {

        surahsSearchInput.addEventListener(
            "input",
            () => {

                searchSurahsPage(
                    surahsSearchInput.value
                );

            }
        );

    }


    if (clearSurahsSearch) {

        clearSurahsSearch.addEventListener(
            "click",
            () => {

                if (surahsSearchInput) {

                    surahsSearchInput.value = "";

                    renderSurahsPage();

                    surahsSearchInput.focus();

                }

            }
        );

    }


    /* =====================================================
       DARK MODE
       ===================================================== */

    const DARK_MODE_KEY =
        "quranDarkMode";


    function applyDarkMode() {

        const dark =
            localStorage.getItem(
                DARK_MODE_KEY
            ) === "true";


        document.body.classList.toggle(
            "dark-mode",
            dark
        );


        document.documentElement.classList.toggle(
            "dark-mode",
            dark
        );


        if (darkModeButton) {

            const label =
                darkModeButton.querySelector("span");


            if (label) {

                label.textContent =
                    dark
                        ? "Light Mode"
                        : "Dark Mode";

            }


            darkModeButton.setAttribute(
                "aria-pressed",
                String(dark)
            );


            darkModeButton.setAttribute(
                "title",
                dark
                    ? "Switch to Light Mode"
                    : "Switch to Dark Mode"
            );

        }

    }


    if (darkModeButton) {

        darkModeButton.addEventListener(
            "click",
            (event) => {

                event.preventDefault();
                event.stopPropagation();


                const dark =
                    !document.body.classList.contains(
                        "dark-mode"
                    );


                localStorage.setItem(
                    DARK_MODE_KEY,
                    String(dark)
                );


                applyDarkMode();


                showToast(
                    dark
                        ? "Dark Mode On"
                        : "Light Mode On"
                );

            }
        );

    }


    /* =====================================================
       SHARE
       ===================================================== */

    if (shareAppButton) {

        shareAppButton.addEventListener(
            "click",
            async () => {

                const shareData = {

                    title:
                        "HAFIZ Yusuf Shuaibu Bauchi Complete Qur’an",

                    text:
                        "Listen to the Holy Qur’an Surah by Surah — HAFIZ Yusuf Shuaibu Bauchi Complete Qur’an.",

                    url:
                        window.location.href

                };


                try {

                    if (navigator.share) {

                        await navigator.share(
                            shareData
                        );

                    } else if (
                        navigator.clipboard
                    ) {

                        await navigator.clipboard.writeText(
                            window.location.href
                        );


                        showToast(
                            "App link copied"
                        );

                    } else {

                        showToast(
                            "Sharing is not available"
                        );

                    }

                } catch (error) {

                    console.log(
                        "Share cancelled or unavailable.",
                        error
                    );

                }

            }
        );

    }


    /* =====================================================
       CONTINUE LISTENING
       ===================================================== */

    function updateContinueCard() {

        if (
            !continueSection ||
            !continueCard
        ) {
            return;
        }


        const savedNumber =
            Number(
                localStorage.getItem(
                    "lastSurah"
                )
            );


        if (
            !savedNumber ||
            savedNumber < 1 ||
            savedNumber > 114
        ) {

            continueSection.style.display =
                "none";

            return;

        }


        const surah =
            surahs.find(
                (item) =>
                    item.number === savedNumber
            );


        if (!surah) {

            continueSection.style.display =
                "none";

            return;

        }


        continueSection.style.display =
            "block";


        continueCard.innerHTML = `

            <div class="continue-card-info">

                <div class="surah-number">
                    ${surah.number}
                </div>

                <div>

                    <h3>
                        ${surah.english}
                    </h3>

                    <p>
                        ${surah.arabic}
                    </p>

                </div>

            </div>

            <button
                class="primary-button"
                id="continuePlayButton"
                type="button">

                ▶️ Continue

            </button>

        `;


        const button =
            document.getElementById(
                "continuePlayButton"
            );


        if (button) {

            button.addEventListener(
                "click",
                () => {

                    loadSurah(
                        surah.number,
                        true
                    );

                }
            );

        }

    }


    /* =====================================================
       PLAY PLAYLIST
       ===================================================== */

    if (playPlaylistButton) {

        playPlaylistButton.addEventListener(
            "click",
            () => {

                if (playlist.length === 0) {

                    showToast(
                        "Playlist is empty"
                    );

                    return;

                }


                playlistIndex = 0;


                loadSurah(
                    playlist[0],
                    true
                );

            }
        );

    }


    /* =====================================================
       PLAYER BUTTONS
       ===================================================== */

    if (playPauseButton) {

        playPauseButton.addEventListener(
            "click",
            togglePlay
        );

    }


    if (previousButton) {

        previousButton.addEventListener(
            "click",
            playPreviousSurah
        );

    }


    if (nextButton) {

        nextButton.addEventListener(
            "click",
            playNextSurah
        );

    }


    if (rewindButton) {

        rewindButton.addEventListener(
            "click",
            rewind10
        );

    }


    if (forwardButton) {

        forwardButton.addEventListener(
            "click",
            forward10
        );

    }


    /* =====================================================
       INITIALIZATION
       ===================================================== */

    renderHome();

    renderSurahsPage();

    renderFavorites();

    renderPlaylist();

    applyDarkMode();

    updateRepeatButton();

    updatePlayerFavorite();

    updateContinueCard();


    /* =====================================================
       RESTORE LAST SURAH
       ===================================================== */

    loadSurah(
        currentSurah,
        false
    );


    /* =====================================================
       RESTORE PAGE
       ===================================================== */

    if (
        [
            "home",
            "surahs",
            "favorites",
            "playlist",
            "about"
        ].includes(currentPage)
    ) {

        showPage(currentPage);

    } else {

        showPage("home");

    }


    console.log(
        "HAFIZ Yusuf Shuaibu Bauchi Complete Qur’an initialized successfully."
    );

});