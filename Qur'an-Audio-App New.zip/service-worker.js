/* =========================================================
   HAFIZ YUSUF SHUAIBU BAUCHI COMPLETE QUR’AN
   SERVICE WORKER
   Version 1.1.1
   Published by: Rabilu Muhammad
   Reciter: Yusuf Shuaibu Bauchi
   ========================================================= */

const CACHE_NAME = "hafiz-yusuf-quran-v1.1.1";

const APP_FILES = [
   "./",
   "./index.html",
   "./style.css",
   "./script.js",
   "./manifest.json",
   "./assets/reciter.jpg",
   "./assets/icon.png",
   "./assets/splash.png"
];


/* =========================================================
   INSTALL
   ========================================================= */

self.addEventListener("install", (event) => {
   
   event.waitUntil(
      
      caches.open(CACHE_NAME)
      
      .then((cache) => {
         
         return cache.addAll(APP_FILES);
         
      })
      
      .catch((error) => {
         
         console.error(
            "Cache installation failed:",
            error
         );
         
      })
      
   );
   
   self.skipWaiting();
   
});


/* =========================================================
   ACTIVATE
   ========================================================= */

self.addEventListener("activate", (event) => {
   
   event.waitUntil(
      
      caches.keys()
      
      .then((cacheNames) => {
         
         return Promise.all(
            
            cacheNames
            
            .filter(
               (name) =>
               name !== CACHE_NAME
            )
            
            .map(
               (name) =>
               caches.delete(name)
            )
            
         );
         
      })
      
      .then(() => {
         
         return self.clients.claim();
         
      })
      
   );
   
});


/* =========================================================
   FETCH
   ========================================================= */

self.addEventListener("fetch", (event) => {
   
   if (
      event.request.method !== "GET"
   ) {
      return;
   }
   
   
   event.respondWith(
      
      fetch(event.request)
      
      .then((networkResponse) => {
         
         if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === "basic"
         ) {
            
            const responseToCache =
               networkResponse.clone();
            
            
            caches.open(CACHE_NAME)
               
               .then((cache) => {
                  
                  cache.put(
                     event.request,
                     responseToCache
                  );
                  
               })
               
               .catch((error) => {
                  
                  console.warn(
                     "Could not update cache:",
                     error
                  );
                  
               });
            
         }
         
         
         return networkResponse;
         
      })
      
      .catch(() => {
         
         return caches.match(
            event.request
         );
         
      })
      
   );
   
});